from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import AuthenticationForm
from django.http import HttpResponseForbidden
from .models import Event, Attendee
from .forms import AttendeeForm, EventForm


def is_superuser(user):
    return user.is_superuser


def event_list(request):
    events = Event.objects.all()
    return render(request, 'events/event_list.html', {'events': events})


def book_ticket(request, pk):
    event = get_object_or_404(Event, pk=pk)
    if request.method == "POST":
        form = AttendeeForm(request.POST)
        if form.is_valid():
            attendee = form.save(commit=False)
            attendee.event = event
            attendee.save()
            return render(request, 'events/success.html', {'event': event})
    else:
        form = AttendeeForm()
    return render(request, 'events/book_ticket.html', {'event': event, 'form': form})


@login_required
@user_passes_test(is_superuser)
def manage_events(request):
    events = Event.objects.all()
    return render(request, 'events/manage_events.html', {'events': events})


@login_required
@user_passes_test(is_superuser)
def create_event(request):
    if request.method == "POST":
        form = EventForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('manage_events')
    else:
        form = EventForm()
    return render(request, 'events/create_event.html', {'form': form})


@login_required
@user_passes_test(is_superuser)
def update_event(request, pk):
    event = get_object_or_404(Event, pk=pk)
    if request.method == "POST":
        form = EventForm(request.POST, instance=event)
        if form.is_valid():
            form.save()
            return redirect('manage_events')
    else:
        form = EventForm(instance=event)
    return render(request, 'events/update_event.html', {'form': form, 'event': event})


@login_required
@user_passes_test(is_superuser)
def delete_event(request, pk):
    event = get_object_or_404(Event, pk=pk)
    event.delete()
    return redirect('manage_events')


def login_view(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            if user.is_superuser:
                login(request, user)
                return redirect('manage_events')
            else:
                return HttpResponseForbidden("Only superusers can log in.")
    else:
        form = AuthenticationForm()
    return render(request, 'events/login.html', {'form': form})
