from django.urls import path
from . import views

urlpatterns = [
    path('', views.event_list, name='event_list'),
    path('book/<int:pk>/', views.book_ticket, name='book_ticket'),
    path('manage/', views.manage_events, name='manage_events'),
    path('manage/create/', views.create_event, name='create_event'),
    path('manage/update/<int:pk>/', views.update_event, name='update_event'),
    path('manage/delete/<int:pk>/', views.delete_event, name='delete_event'),
    path('login/', views.login_view, name='login'),
]
