from django.contrib import admin
from .models import Event, Attendee

# Register your models here
@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ('name', 'date', 'time', 'location')
    search_fields = ('name', 'description', 'location')
    list_filter = ('date', 'location')


@admin.register(Attendee)
class AttendeeAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'phone', 'event')
    search_fields = ('name', 'email', 'phone')
    list_filter = ('event',)
